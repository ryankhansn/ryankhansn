from fastapi import APIRouter, Depends, HTTPException, status, Body
import requests
import os
import json
from dotenv import load_dotenv
from typing import Dict, Optional, List
from datetime import datetime

# Changed from relative to absolute imports
from db import db, get_db, otp_requests_collection
from routes.auth import get_current_user
from routes.wallet import debit_wallet, get_or_create_wallet
# Import from models package
from models import OtpRequestCreate, OtpRequestResponse

# Load environment variables
load_dotenv()

# Get API key from environment variables
OTPB_API_KEY = os.getenv("OTPB_API_KEY")
if not OTPB_API_KEY:
    print("Warning: OTPB_API_KEY not found in environment variables")

# Base URL for OTP Bazaar API
BASE_URL = "https://otpbazzar.com/api"

# Create router
router = APIRouter()

# Helper function to make API requests to OTP Bazaar
async def make_api_request(endpoint: str, method: str = "GET", data: Dict = None) -> Dict:
    """Make API request to OTP Bazaar"""
    url = f"{BASE_URL}/{endpoint}"
    headers = {
        "Authorization": f"Bearer {OTPB_API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=data)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, json=data)
        else:
            raise ValueError(f"Unsupported HTTP method: {method}")
        
        response.raise_for_status()  # Raise exception for HTTP errors
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"API request error: {str(e)}")
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, 
                            detail=f"Error communicating with OTP service: {str(e)}")

@router.get("/services", response_model=List[Dict])
async def get_available_services(current_user = Depends(get_current_user)):
    """Get list of available services from OTP Bazaar"""
    try:
        result = await make_api_request("services")
        return result.get("services", [])
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                            detail=f"Failed to fetch services: {str(e)}")

@router.post("/request", response_model=Dict)
async def create_otp_request(
    request_data: OtpRequestCreate = Body(...),
    current_user = Depends(get_current_user)
):
    """Create a new OTP request with OTP Bazaar"""
    user_id = str(current_user.email)
    service_id = request_data.service_id
    
    # Prepare request to OTP Bazaar API
    api_data = {
        "service": service_id,
        "action": "getNumber"
    }
    
    try:
        # Call OTP Bazaar API
        result = await make_api_request("request", method="POST", data=api_data)
        
        if not result.get("success"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                                detail=f"OTP service error: {result.get('message', 'Unknown error')}")
        
        # Extract response data
        number = result.get("number")
        request_id = result.get("request_id")
        price = result.get("price", 0)
        
        # Debit user's wallet
        try:
            await debit_wallet(user_id, price, f"OTP request for service {service_id}")
        except ValueError as e:
            # If wallet debit fails, cancel the OTP request
            await make_api_request(f"cancel/{request_id}", method="POST")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
        
        # Save request to database
        otp_request = {
            "user_id": user_id,
            "service_id": service_id,
            "number": number,
            "external_request_id": request_id,
            "status": "active",
            "price": price,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        result = otp_requests_collection.insert_one(otp_request)
        otp_request["id"] = str(result.inserted_id)
        
        return {
            "success": True,
            "request_id": otp_request["id"],
            "number": number,
            "status": "active"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Failed to create OTP request: {str(e)}")

@router.get("/status/{request_id}", response_model=Dict)
@router.get("/otpbazaar/status/{request_id}", response_model=Dict)
async def check_otp_status(request_id: str, current_user = Depends(get_current_user)):
    """Check status of an OTP request"""
    user_id = str(current_user.email)
    
    # Get request from database
    otp_request = otp_requests_collection.find_one({"_id": request_id, "user_id": user_id})
    if not otp_request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="OTP request not found")
    
    external_id = otp_request.get("external_request_id")
    
    try:
        # Call OTP Bazaar API to check status
        result = await make_api_request(f"status/{external_id}", method="GET")
        
        # Update local status if needed
        new_status = result.get("status")
        otp_code = result.get("code")
        
        update_data = {
            "updated_at": datetime.utcnow()
        }
        
        # If OTP code is received, mark as completed
        if otp_code:
            update_data["status"] = "completed"
            update_data["otp_code"] = otp_code
        else:
            update_data["status"] = new_status
        
        # Update the database record
        otp_requests_collection.update_one(
            {"_id": request_id},
            {"$set": update_data}
        )
        
        return {
            "request_id": request_id,
            "status": update_data["status"],
            "number": otp_request.get("number"),
            "otp_code": otp_code,
            "service_id": otp_request.get("service_id")
        }
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Failed to check OTP status: {str(e)}")

@router.post("/cancel/{request_id}", response_model=Dict)
@router.post("/otpbazaar/cancel/{request_id}", response_model=Dict)
async def cancel_otp_request(request_id: str, current_user = Depends(get_current_user)):
    """Cancel an active OTP request and process refund"""
    user_id = str(current_user.email)
    
    # Get request from database
    otp_request = otp_requests_collection.find_one({"_id": request_id, "user_id": user_id})
    if not otp_request:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="OTP request not found")
    
    if otp_request.get("status") not in ["active", "pending"]:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, 
                            detail="Cannot cancel completed or already cancelled request")
    
    external_id = otp_request.get("external_request_id")
    price = otp_request.get("price", 0)
    
    try:
        # Call OTP Bazaar API to cancel
        result = await make_api_request(f"cancel/{external_id}", method="POST")
        
        # Update local status
        otp_requests_collection.update_one(
            {"_id": request_id},
            {
                "$set": {
                    "status": "cancelled",
                    "updated_at": datetime.utcnow()
                }
            }
        )
        
        # Process refund to user's wallet
        if price > 0:
            await credit_wallet(
                user_id, 
                price, 
                f"Refund for cancelled OTP request {request_id}"
            )
        
        return {
            "success": True,
            "message": "Request cancelled, refund processed"
        }
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                            detail=f"Failed to cancel OTP request: {str(e)}")