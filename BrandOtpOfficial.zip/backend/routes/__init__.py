# This file makes the routes directory a Python package
# Import and include your route modules here

from .auth import router as auth_router
from .services import router as services_router
from .wallet import router as wallet_router
from .otp_requests import router as otp_router
from .admin import router as admin_router
from .payments import router as payments_router