from fastapi import FastAPI, APIRouter, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import time
import logging
from datetime import datetime
from dotenv import load_dotenv
from routes import auth_router, services_router, wallet_router, otp_router, admin_router, payments_router

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Load environment variables
load_dotenv()

app = FastAPI()

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    request_id = f"{int(time.time())}-{os.urandom(4).hex()}"
    start_time = time.time()
    
    # Log request details
    logging.info(f"Request {request_id} started: {request.method} {request.url.path}")
    
    # Process the request
    response = await call_next(request)
    
    # Calculate processing time
    process_time = time.time() - start_time
    
    # Log response details
    logging.info(f"Request {request_id} completed: {response.status_code} in {process_time:.4f}s")
    
    return response

# Configure CORS with FRONTEND_ORIGIN from .env
app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("FRONTEND_ORIGIN", "http://127.0.0.1:5500"), "http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth_router, prefix="/auth", tags=["Auth"])
app.include_router(services_router, prefix="/services", tags=["Services"])
app.include_router(wallet_router, prefix="/wallet", tags=["Wallet"])
app.include_router(otp_router, prefix="/otp", tags=["OTP"])
app.include_router(admin_router, prefix="/admin", tags=["Admin"])
app.include_router(payments_router, prefix="/payments", tags=["Payments"])

# Serve frontend
app.mount("/frontend", StaticFiles(directory="../frontend"), name="frontend")

@app.get("/")
async def read_index():
    return FileResponse('../frontend/index.html')