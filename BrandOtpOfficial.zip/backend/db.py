import os
from pymongo import MongoClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get MongoDB connection string from environment variable
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")

# Create MongoDB client
client = MongoClient(MONGO_URI)

# Get database
db = client.get_database("brandotp_db")

# Define collections
users_collection = db.users
transactions_collection = db.transactions
orders_collection = db.orders
services_collection = db.services
otp_requests_collection = db.otp_requests

# Create indexes for better performance
users_collection.create_index("email", unique=True)
orders_collection.create_index("order_id", unique=True)
otp_requests_collection.create_index("request_id", unique=True)

# Function to get database connection
def get_db():
    return db

# User management helper functions
def get_user_by_email(email):
    return users_collection.find_one({"email": email})

def get_user_by_username(username):
    return users_collection.find_one({"username": username})

def create_user(user_data):
    result = users_collection.insert_one(user_data)
    user_data["id"] = str(result.inserted_id)
    return user_data

def user_exists(email, username):
    return users_collection.find_one({"$or": [{"email": email}, {"username": username}]})