from fastapi import APIRouter, Depends, HTTPException, status, Path
# Changed from relative to absolute imports
from db import services_collection, get_db
from models import ServiceCreate, ServiceUpdate, ServiceResponse, ServiceInDB
from datetime import datetime
from typing import List
from bson import ObjectId

# Create router
router = APIRouter()

# Define routes for services
@router.get("/", response_model=List[ServiceResponse])
async def get_services(db=Depends(get_db)):
    """Get all active services"""
    services = list(services_collection.find({"status": "active"}))
    # Convert ObjectId to string for JSON serialization
    for service in services:
        service["id"] = str(service["_id"])
        del service["_id"]
    return services

@router.post("/add", response_model=ServiceResponse, status_code=status.HTTP_201_CREATED)
async def add_service(service: ServiceCreate, db=Depends(get_db)):
    """Add a new service"""
    # Create service document
    service_dict = service.dict()
    service_dict["created_at"] = datetime.now(timezone.utc)
    
    # Insert into database
    result = services_collection.insert_one(service_dict)
    
    # Return created service
    created_service = services_collection.find_one({"_id": result.inserted_id})
    created_service["id"] = str(created_service["_id"])
    del created_service["_id"]
    
    return created_service

@router.put("/{service_id}", response_model=ServiceResponse)
async def update_service(service_id: str = Path(..., title="The ID of the service to update"), 
                        service_update: ServiceUpdate = None, 
                        db=Depends(get_db)):
    """Update a service's my_price or status"""
    # Check if service exists
    try:
        object_id = ObjectId(service_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid service ID format")
    
    existing_service = services_collection.find_one({"_id": object_id})
    if not existing_service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    # Update only provided fields
    update_data = {k: v for k, v in service_update.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No valid update data provided")
    
    # Update service
    services_collection.update_one({"_id": object_id}, {"$set": update_data})
    
    # Return updated service
    updated_service = services_collection.find_one({"_id": object_id})
    updated_service["id"] = str(updated_service["_id"])
    del updated_service["_id"]
    
    return updated_service

@router.delete("/{service_id}", response_model=ServiceResponse)
async def delete_service(service_id: str = Path(..., title="The ID of the service to delete"), 
                        db=Depends(get_db)):
    """Soft delete a service by setting status to inactive"""
    # Check if service exists
    try:
        object_id = ObjectId(service_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid service ID format")
    
    existing_service = services_collection.find_one({"_id": object_id})
    if not existing_service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    # Soft delete by setting status to inactive
    services_collection.update_one({"_id": object_id}, {"$set": {"status": "inactive"}})
    
    # Return updated service
    updated_service = services_collection.find_one({"_id": object_id})
    updated_service["id"] = str(updated_service["_id"])
    del updated_service["_id"]
    
    return updated_service