from pydantic import BaseModel
from typing import Optional
from datetime import datetime   # <-- ये import जरूरी है
from pydantic import BaseModel
from typing import Optional

# Signup / create user
class UserCreate(BaseModel):
    username: str
    email: str
    password: str

# User stored in DB (hashed password etc.)
class UserInDB(BaseModel):
    id: Optional[str] = None
    username: str
    email: str
    hashed_password: str
    created_at: Optional[datetime] = None   # ✅ सही syntax
# Userclass User(BaseModel):
class User(BaseModel):
    id: Optional[str] = None
    username: str
    email: str
    balance: float = 0.0
    created_at: Optional[datetime] = None   # ✅ सही syntax

# JWT token response
class Token(BaseModel):
    access_token: str
    token_type: str

# JWT token payload
class TokenData(BaseModel):
    username: Optional[str] = None