import requests
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class PayProSDK:
    def __init__(self, base_url="https://pay0.shop"):
        self.base_url = base_url
    
    def create_order(self, customer_mobile, user_token, amount, order_id, redirect_url, remark1="", remark2=""):
        """
        Create a payment order with the Pay0 payment gateway
        
        Args:
            customer_mobile (str): Customer's mobile number
            user_token (str): Merchant's API token
            amount (float): Payment amount
            order_id (str): Unique order identifier
            redirect_url (str): URL to redirect after payment
            remark1 (str, optional): Additional information
            remark2 (str, optional): Additional information
            
        Returns:
            dict: Response from the payment gateway
        """
        # In a real implementation, this would make an API call to the payment gateway
        # For now, we'll return a simulated response
        try:
            # Construct API endpoint
            endpoint = f"{self.base_url}/api/create-order"
            
            # Prepare request payload
            payload = {
                "customer_mobile": customer_mobile,
                "token": user_token,
                "amount": amount,
                "order_id": order_id,
                "redirect_url": redirect_url,
                "remark1": remark1,
                "remark2": remark2
            }
            
            # In a real implementation, this would be an actual API call
            # response = requests.post(endpoint, json=payload)
            # result = response.json()
            
            # For now, simulate a successful response
            payment_url = f"{self.base_url}/pay?order_id={order_id}&amount={amount}&token={user_token}"
            result = {
                "success": True,
                "order_id": order_id,
                "payment_url": payment_url,
                "amount": amount,
                "status": "PENDING"
            }
            
            return result
            
        except Exception as e:
            # Handle exceptions
            return {
                "success": False,
                "error": str(e)
            }