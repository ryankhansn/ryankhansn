from pydantic import BaseModel
from typing import Optional, Literal
from datetime import datetime

class ServiceBase(BaseModel):
    name: str
    description: Optional[str] = None
    base_price: float
    my_price: float
    status: Literal['active', 'inactive'] = 'active'

class ServiceCreate(ServiceBase):
    pass

class ServiceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    base_price: Optional[float] = None
    my_price: Optional[float] = None
    status: Optional[Literal['active', 'inactive']] = None

class ServiceInDB(ServiceBase):
    id: str
    created_at: datetime

class ServiceResponse(ServiceBase):
    id: str
    created_at: datetime