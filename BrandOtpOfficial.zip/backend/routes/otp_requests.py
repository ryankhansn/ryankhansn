from fastapi import APIRouter, Depends, HTTPException, status, Path, Body, Query
from datetime import datetime
from bson import ObjectId
from typing import Dict, Optional, List
import pymongo
import os
import sys

parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parent_dir)

# Changed from relative to absolute imports
from db import db, get_db, services_collection, otp_requests_collection
from routes.auth import get_current_user
from routes.wallet import get_or_create_wallet
# Import from models package
from models import OtpRequestCreate, OtpRequestResponse, OtpRequestInDB

# Create router
router = APIRouter()

@router.get("/history", response_model=List[OtpRequestResponse])
async def get_otp_history(
    limit: int = Query(10, ge=1, le=100),
    skip: int = Query(0, ge=0),
    current_user = Depends(get_current_user)
):
    """Get user's OTP request history"""
    user_id = str(current_user.email)
    
    # Get OTP requests for the user
    cursor = otp_requests_collection.find({"user_id": user_id})\
        .sort("created_at", pymongo.DESCENDING)\
        .skip(skip)\
        .limit(limit)
    
    # Convert to list of OtpRequestResponse
    otp_requests = []
    for doc in cursor:
        doc["id"] = str(doc["_id"])
        del doc["_id"]
        otp_requests.append(doc)
    
    return otp_requests

# Router is already initialized above

@router.post("/request", response_model=dict)
async def request_otp(request: OtpRequestCreate, current_user = Depends(get_current_user)):
    """Request a new OTP for a service"""
    # Validate service_id
    try:
        service_object_id = ObjectId(request.service_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid service ID format")
    
    # Get service details
    service = services_collection.find_one({"_id": service_object_id})
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    if service["status"] != "active":
        raise HTTPException(status_code=400, detail="Service is not active")
    
    # Get user wallet
    user_id = str(current_user.email)
    wallet = await get_or_create_wallet(user_id)
    
    # Check if user has enough balance
    service_price = service["my_price"]
    if wallet["balance"] < service_price:
        raise HTTPException(status_code=400, detail="Insufficient wallet balance")
    
    # Deduct from wallet
    transaction = {
        "amount": service_price,
        "type": "debit",
        "ref_id": str(service_object_id),
        "timestamp": datetime.utcnow()
    }
    
    new_balance = wallet["balance"] - service_price
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    # Create OTP request
    otp_request = {
        "user_id": user_id,
        "service_id": request.service_id,
        "number": None,  # Will be filled by admin/system
        "status": "pending",
        "otp_code": None,  # Will be filled when OTP is received
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }
    
    result = otp_requests_collection.insert_one(otp_request)
    request_id = str(result.inserted_id)
    
    return {
        "request_id": request_id,
        "status": "pending",
        "message": "OTP request created successfully",
        "service": service["name"],
        "price": service_price,
        "new_wallet_balance": new_balance
    }

@router.get("/status/{request_id}", response_model=dict)
async def get_otp_status(request_id: str = Path(...), current_user = Depends(get_current_user)):
    """Get the status of an OTP request"""
    # Validate request_id
    try:
        request_object_id = ObjectId(request_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid request ID format")
    
    # Get user ID
    user_id = str(current_user.email)
    
    # Get OTP request
    otp_request = otp_requests_collection.find_one({
        "_id": request_object_id,
        "user_id": user_id
    })
    
    if not otp_request:
        raise HTTPException(status_code=404, detail="OTP request not found")
    
    # Prepare response
    response = {
        "request_id": request_id,
        "status": otp_request["status"],
        "created_at": otp_request["created_at"],
        "updated_at": otp_request["updated_at"]
    }
    
    # Include OTP code if available
    if otp_request["otp_code"]:
        response["otp_code"] = otp_request["otp_code"]
    
    return response

@router.post("/cancel/{request_id}", response_model=dict)
async def cancel_otp_request(request_id: str = Path(...), current_user = Depends(get_current_user)):
    """Cancel an OTP request and refund the wallet"""
    # Validate request_id
    try:
        request_object_id = ObjectId(request_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid request ID format")
    
    # Get user ID
    user_id = str(current_user.email)
    
    # Get OTP request
    otp_request = otp_requests_collection.find_one({
        "_id": request_object_id,
        "user_id": user_id
    })
    
    if not otp_request:
        raise HTTPException(status_code=404, detail="OTP request not found")
    
    # Check if request can be cancelled
    if otp_request["status"] not in ["pending", "active"]:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot cancel request with status '{otp_request['status']}'"
        )
    
    # Get service details for refund
    service_id = otp_request["service_id"]
    try:
        service_object_id = ObjectId(service_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid service ID in request")
    
    service = services_collection.find_one({"_id": service_object_id})
    if not service:
        raise HTTPException(status_code=404, detail="Service not found for refund")
    
    # Refund wallet
    refund_amount = service["my_price"]
    wallet = await get_or_create_wallet(user_id)
    
    # Create refund transaction
    transaction = {
        "amount": refund_amount,
        "type": "credit",
        "ref_id": request_id,
        "timestamp": datetime.utcnow()
    }
    
    new_balance = wallet["balance"] + refund_amount
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    # Update OTP request status
    otp_requests_collection.update_one(
        {"_id": request_object_id},
        {
            "$set": {
                "status": "cancelled",
                "updated_at": datetime.utcnow()
            }
        }
    )
    
    return {
        "request_id": request_id,
        "status": "cancelled",
        "message": "OTP request cancelled and refunded successfully",
        "refund_amount": refund_amount,
        "new_wallet_balance": new_balance
    }