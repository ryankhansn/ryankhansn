// Check for authentication token immediately when page loads
window.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    
    if (!token) {
        // No token found, redirect to login
        window.location.href = 'login.html';
        return;
    }

    // Add logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    logoutBtn.addEventListener('click', function() {
        localStorage.removeItem('token');
        alert('You have been logged out');
        window.location.href = 'login.html';
    });

    try {
        // Verify token with backend
        const response = await fetch('http://127.0.0.1:8000/auth/me', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Token validation failed');
        }

        const userData = await response.json();
        
        // Update welcome message with username
        const welcomeMessage = document.getElementById('welcomeMessage');
        welcomeMessage.textContent = `Welcome, ${userData.username}`;

    } catch (error) {
        console.error('Authentication failed:', error);
        // Clear localStorage and redirect to login
        localStorage.clear();
        window.location.href = 'login.html';
    }
});

// Note: Logout functionality is already handled in the DOMContentLoaded event listener above