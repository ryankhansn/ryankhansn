from fastapi import APIRouter, Depends, HTTPException, status, Request, Query
from datetime import datetime
import uuid
import os
import json
from dotenv import load_dotenv
from typing import Dict, Optional, List
import pymongo

# Changed from relative to absolute imports
from db import db, get_db, orders_collection
from routes.auth import get_current_user
from utils.create_order import PayProSDK
from utils.order_status_sdk import OrderStatusSDK
from models.payment import PaymentOrderCreate, PaymentOrderResponse
from routes.wallet import add_funds_to_wallet, get_or_create_wallet, credit_wallet

# Load environment variables
load_dotenv()

# Get environment variables
PAY0_USER_TOKEN = os.getenv("PAY0_USER_TOKEN")
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5500")
PAY0_REDIRECT_URL = os.getenv("PAY0_REDIRECT_URL", f"{FRONTEND_URL}/payment-callback")

# Create router
router = APIRouter()

@router.get("/history", response_model=List[Dict])
async def get_payment_history(current_user = Depends(get_current_user)):
    """Get payment history for the current user"""
    user_id = str(current_user.email)
    
    # Get all orders for the user
    orders = list(orders_collection.find(
        {"user_id": user_id},
        {"_id": 0}
    ).sort("created_at", pymongo.DESCENDING))
    
    # Convert datetime objects to strings for JSON serialization
    for order in orders:
        if "created_at" in order:
            order["created_at"] = order["created_at"].isoformat()
        if "updated_at" in order:
            order["updated_at"] = order["updated_at"].isoformat()
    
    return orders

# Initialize SDK instances

# Initialize SDK instances
sdk = PayProSDK()
status_sdk = OrderStatusSDK("https://pay0.shop")

@router.post("/create_order", response_model=PaymentOrderResponse)
async def create_payment_order(
    payment_data: PaymentOrderCreate, 
    current_user = Depends(get_current_user)
):
    """Create a new payment order"""
    if payment_data.amount <= 0:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Amount must be greater than zero")
    
    # Generate a unique order ID
    order_id = str(uuid.uuid4())
    
    # Get user details
    user_id = str(current_user.email)  # Using email as user_id for consistency
    customer_mobile = current_user.phone if hasattr(current_user, 'phone') else ""  # Get phone if available
    
    # Create order with payment gateway
    order_result = sdk.create_order(
        customer_mobile=customer_mobile,
        user_token=PAY0_USER_TOKEN,
        amount=payment_data.amount,
        order_id=order_id,
        redirect_url=PAY0_REDIRECT_URL,
        remark1="Wallet recharge",
        remark2=user_id
    )
    
    # Save order information to database
    order_data = {
        "user_id": user_id,
        "order_id": order_id,
        "amount": payment_data.amount,
        "status": "PENDING",
        "payment_url": order_result.get("payment_url"),
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow(),
        "transaction_id": None
    }
    
    result = orders_collection.insert_one(order_data)
    
    return {
        "order_id": order_id,
        "payment_url": order_result.get("payment_url"),
        "amount": payment_data.amount,
        "status": "PENDING"
    }

@router.get("/status/{order_id}")
async def check_payment_status(order_id: str, current_user = Depends(get_current_user)):
    """Check the status of a payment order"""
    user_id = str(current_user.email)
    
    # Get order from database
    order = orders_collection.find_one({"order_id": order_id, "user_id": user_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Check status with payment gateway
    status_result = status_sdk.check_order_status(PAY0_USER_TOKEN, order_id)
    
    # Get current status
    current_status = order.get("status")
    new_status = status_result.get("status")
    
    # Update order status in database if it has changed
    if new_status != current_status:
        orders_collection.update_one(
            {"order_id": order_id},
            {
                "$set": {
                    "status": new_status,
                    "updated_at": datetime.utcnow()
                }
            }
        )
        
        # If payment was successful and not already processed, add funds to user's wallet
        if new_status == "SUCCESS" and current_status != "SUCCESS":
            try:
                amount = order.get("amount")
                await credit_wallet(user_id, amount, order_id)
                
                # Get updated wallet balance
                wallet = await get_or_create_wallet(user_id)
                wallet_balance = wallet.get("balance")
            except Exception as e:
                # Log the error but don't fail the request
                print(f"Error adding funds to wallet: {str(e)}")
                wallet_balance = None
        else:
            wallet_balance = None
    else:
        wallet_balance = None
    
    return {
        "order": {
            "order_id": order_id,
            "status": new_status,
            "amount": order.get("amount"),
            "created_at": order.get("created_at"),
            "updated_at": datetime.utcnow()
        },
        "wallet_balance": wallet_balance
    }

@router.post("/webhook")
async def payment_webhook(request: Request):
    """Handle payment gateway webhook"""
    # This endpoint would be called by the payment gateway to update the order status
    # In a real implementation, you would verify the webhook with a signature
    
    try:
        # Parse the incoming webhook data
        webhook_data = await request.json()
        
        # Extract data from webhook
        status = webhook_data.get("status")
        order_id = webhook_data.get("order_id")
        remark1 = webhook_data.get("remark1")
        transaction_id = webhook_data.get("transaction_id")
        
        if not order_id or not status:
            return {"message": "Missing required fields", "success": False}
        
        # Find the order in the database
        order = orders_collection.find_one({"order_id": order_id})
        if not order:
            return {"message": "Order not found", "success": False}
        
        # Get current status before updating
        current_status = order.get("status")
        
        # Determine the status to set
        new_status = status if status == "SUCCESS" else "FAILED"
        
        # Update order status in database
        update_data = {
            "status": new_status,
            "updated_at": datetime.utcnow()
        }
        
        if transaction_id:
            update_data["transaction_id"] = transaction_id
        
        orders_collection.update_one(
            {"order_id": order_id},
            {"$set": update_data}
        )
        
        # If payment was successful and not already processed, add funds to user's wallet
        if new_status == "SUCCESS" and current_status != "SUCCESS":
            try:
                user_id = order.get("user_id")
                amount = order.get("amount")
                await credit_wallet(user_id, amount, order_id)
            except Exception as e:
                # Log the error but don't fail the webhook
                print(f"Error adding funds to wallet: {str(e)}")
        
        return {"message": "Webhook processed", "success": True}
    
    except Exception as e:
        print(f"Error processing webhook: {str(e)}")
        return {"message": "Error processing webhook", "success": False}