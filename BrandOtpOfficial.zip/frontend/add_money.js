document.addEventListener('DOMContentLoaded', () => {
    const addMoneyForm = document.getElementById('addMoneyForm');
    const addMoneyBtn = document.getElementById('addMoneyBtn');

    addMoneyForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const amount = document.getElementById('amount').value;

        if (!amount || amount < 1) {
            alert('Please enter a valid amount');
            return;
        }

        try {
            addMoneyBtn.disabled = true;
            addMoneyBtn.textContent = 'Processing...';
            const token = localStorage.getItem('token');
            
            if (!token) {
                alert('Please login first');
                window.location.href = '/login.html';
                return;
            }

            // Create payment order
            const response = await fetch('http://127.0.0.1:8000/payments/create_order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ amount: parseInt(amount) })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.detail || 'Failed to create payment order');
            }

            // Check if redirect URL is provided
            if (data.redirect_url) {
                // Open payment gateway in new tab
                window.open(data.redirect_url, '_blank');
                
                // Start polling for payment status
                let attempts = 0;
                const maxAttempts = 60; // Poll for 5 minutes (5s interval)
                const pollInterval = 5000; // 5 seconds

                const checkPaymentStatus = async () => {
                    try {
                        const statusResponse = await fetch(`http://127.0.0.1:8000/payments/status/${data.order_id}`, {
                            headers: {
                                'Authorization': `Bearer ${token}`
                            }
                        });

                        const statusData = await statusResponse.json();

                        if (statusData.status === 'success') {
                            alert('Payment successful! Balance updated.');
                            window.location.href = 'wallet.html';
                            return;
                        } else if (statusData.status === 'failed') {
                            alert('Payment failed');
                            addMoneyBtn.disabled = false;
                            addMoneyBtn.textContent = 'Add Money';
                            return;
                        }

                        // Continue polling if payment is pending
                        attempts++;
                        if (attempts < maxAttempts) {
                            setTimeout(checkPaymentStatus, pollInterval);
                        } else {
                            alert('Payment status check timed out. Please check your wallet for confirmation.');
                            addMoneyBtn.disabled = false;
                            addMoneyBtn.textContent = 'Add Money';
                        }
                    } catch (error) {
                        console.error('Error checking payment status:', error);
                        alert('Error checking payment status. Please check your wallet for confirmation.');
                        addMoneyBtn.disabled = false;
                        addMoneyBtn.textContent = 'Add Money';
                    }
                };

                // Start polling after a short delay
                setTimeout(checkPaymentStatus, pollInterval);
            } else {
                throw new Error('No payment URL received from server');
            }
        } catch (error) {
            console.error('Payment error:', error);
            alert(error.message || 'Payment failed');
            addMoneyBtn.disabled = false;
            addMoneyBtn.textContent = 'Add Money';
        }
    });
});