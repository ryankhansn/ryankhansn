from fastapi import APIRouter, Depends, HTTPException, status, Query
from datetime import datetime, date, timezone
from bson import ObjectId
from pymongo.collection import Collection
from typing import Dict, List, Optional

from db import db, get_db
from routes.auth import get_current_user

# Create router
router = APIRouter()

@router.get("/transactions")
async def get_wallet_transactions(
    limit: int = Query(10, ge=1, le=100),
    skip: int = Query(0, ge=0),
    transaction_type: Optional[str] = Query(None, description="Filter by transaction type (credit/debit)"),
    start_date: Optional[str] = Query(None, description="Start date for filtering (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date for filtering (YYYY-MM-DD)"),
    current_user = Depends(get_current_user)
):
    """Get current user's wallet transactions with optional filters
    
    Args:
        limit: Maximum number of transactions to return
        skip: Number of transactions to skip (for pagination)
        transaction_type: Filter by transaction type (credit/debit)
        start_date: Start date for filtering (YYYY-MM-DD)
        end_date: End date for filtering (YYYY-MM-DD)
        
    Returns:
        Dict with transactions, total count, and pagination info
    """
    user_id = str(current_user.email)  # Using email as user_id for consistency
    wallet = await get_or_create_wallet(user_id)
    
    # Get transactions
    transactions = wallet.get("transactions", [])
    filtered_transactions = transactions.copy()
    
    # Apply type filter if provided
    if transaction_type:
        if transaction_type not in ["credit", "debit"]:
            raise HTTPException(status_code=400, detail="Transaction type must be 'credit' or 'debit'")
        filtered_transactions = [t for t in filtered_transactions if t["type"] == transaction_type]
    
    # Apply date filters if provided
    if start_date:
        try:
            start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
            filtered_transactions = [t for t in filtered_transactions if t["timestamp"] >= start_datetime]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD")
    
    if end_date:
        try:
            # Set end_datetime to the end of the specified day
            end_datetime = datetime.strptime(end_date, "%Y-%m-%d")
            end_datetime = end_datetime.replace(hour=23, minute=59, second=59)
            filtered_transactions = [t for t in filtered_transactions if t["timestamp"] <= end_datetime]
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD")
    
    # Sort by timestamp (newest first) and apply pagination
    sorted_transactions = sorted(filtered_transactions, key=lambda x: x["timestamp"], reverse=True)
    paginated_transactions = sorted_transactions[skip:skip+limit]
    
    return {
        "transactions": paginated_transactions,
        "total": len(filtered_transactions),
        "limit": limit,
        "skip": skip
    }

# Initialize wallets collection
wallets_collection = db.wallets

# Helper function to get or create a wallet for a user
async def get_or_create_wallet(user_id: str, db=Depends(get_db)) -> Dict:
    """Get or create a wallet for a user"""
    wallet = db.wallets.find_one({"user_id": user_id})
    
    if not wallet:
        # Create new wallet if it doesn't exist
        wallet = {
            "user_id": user_id,
            "balance": 0,
            "transactions": [],
            "created_at": datetime.now(timezone.utc)
        }
        result = db.wallets.insert_one(wallet)
        wallet["_id"] = result.inserted_id
    
    return wallet

# Helper function to add funds to a wallet (for internal use)
async def add_funds_to_wallet(user_id: str, amount: float, ref_id: str) -> Dict:
    """Add funds to a user's wallet (for internal use by other services)"""
    if amount <= 0:
        raise ValueError("Amount must be greater than zero")
    
    wallet = await get_or_create_wallet(user_id)
    
    # Create transaction record
    transaction = {
        "amount": amount,
        "type": "credit",
        "ref_id": ref_id,
        "timestamp": datetime.now(timezone.utc)
    }
    
    # Update wallet balance and add transaction
    new_balance = wallet["balance"] + amount
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    return {
        "transaction": transaction,
        "new_balance": new_balance
    }

# Helper function to credit a wallet (alias for add_funds_to_wallet)
async def credit_wallet(user_id: str, amount: float, ref_id: str) -> Dict:
    """Credit funds to a user's wallet
    
    Args:
        user_id (str): The user ID
        amount (float): The amount to credit
        ref_id (str): Reference ID for the transaction
        
    Returns:
        Dict: Transaction details and new balance
    """
    return await add_funds_to_wallet(user_id, amount, ref_id)

# Helper function to debit a wallet
async def debit_wallet(user_id: str, amount: float, ref_id: str) -> Dict:
    """Debit funds from a user's wallet
    
    Args:
        user_id (str): The user ID
        amount (float): The amount to debit
        ref_id (str): Reference ID for the transaction
        
    Returns:
        Dict: Transaction details and new balance
        
    Raises:
        ValueError: If amount is not positive or if balance is insufficient
    """
    if amount <= 0:
        raise ValueError("Amount must be greater than zero")
    
    wallet = await get_or_create_wallet(user_id)
    
    # Check if sufficient balance
    if wallet["balance"] < amount:
        raise ValueError("Insufficient balance")
    
    # Create transaction record
    transaction = {
        "amount": amount,
        "type": "debit",
        "ref_id": ref_id,
        "timestamp": datetime.now(timezone.utc)
    }
    
    # Update wallet balance and add transaction
    new_balance = wallet["balance"] - amount
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    return {
        "transaction": transaction,
        "new_balance": new_balance
    }

@router.get("/balance")
async def get_wallet_balance(current_user = Depends(get_current_user)):
    """Get current user's wallet balance"""
    user_id = str(current_user.email)  # Using email as user_id for consistency
    wallet = await get_or_create_wallet(user_id)
    
    return {
        "balance": wallet["balance"],
        "user_id": user_id
    }

@router.post("/add")
async def add_to_wallet(amount: float, ref_id: str, current_user = Depends(get_current_user)):
    """Add funds to wallet (credit transaction)"""
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than zero")
    
    user_id = str(current_user.email)
    wallet = await get_or_create_wallet(user_id)
    
    # Create transaction record
    transaction = {
        "amount": amount,
        "type": "credit",
        "ref_id": ref_id,
        "timestamp": datetime.now(timezone.utc)
    }
    
    # Update wallet balance and add transaction
    new_balance = wallet["balance"] + amount
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    return {
        "message": "Funds added successfully",
        "transaction": transaction,
        "new_balance": new_balance
    }

@router.post("/deduct")
async def deduct_from_wallet(amount: float, ref_id: str, current_user = Depends(get_current_user)):
    """Deduct funds from wallet (debit transaction)"""
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be greater than zero")
    
    user_id = str(current_user.email)
    wallet = await get_or_create_wallet(user_id)
    
    # Check if sufficient balance
    if wallet["balance"] < amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    
    # Create transaction record
    transaction = {
        "amount": amount,
        "type": "debit",
        "ref_id": ref_id,
        "timestamp": datetime.now(timezone.utc)
    }
    
    # Update wallet balance and add transaction
    new_balance = wallet["balance"] - amount
    db.wallets.update_one(
        {"user_id": user_id},
        {
            "$set": {"balance": new_balance},
            "$push": {"transactions": transaction}
        }
    )
    
    return {
        "message": "Funds deducted successfully",
        "transaction": transaction,
        "new_balance": new_balance
    }