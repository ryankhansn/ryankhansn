/**
 * API Interaction Module for BrandOtp Frontend
 */

// API Base URL - Change this to match your backend URL
const API_BASE_URL = 'http://localhost:8000';

// Utility function for making API requests
async function apiRequest(endpoint, method = 'GET', data = null, token = null) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const headers = {
        'Content-Type': 'application/json'
    };
    
    // Add authorization token if provided
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    const options = {
        method,
        headers,
        credentials: 'include'
    };
    
    // Add request body for non-GET requests
    if (data && method !== 'GET') {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        
        // Parse JSON response if available
        const contentType = response.headers.get('content-type');
        const result = contentType && contentType.includes('application/json') 
            ? await response.json() 
            : await response.text();
        
        // Handle API errors
        if (!response.ok) {
            throw new Error(result.detail || result.message || 'API request failed');
        }
        
        return result;
    } catch (error) {
        console.error('API Request Error:', error);
        throw error;
    }
}

// Authentication functions
const auth = {
    // Login user
    login: async (email, password) => {
        return apiRequest('/auth/login', 'POST', { email, password });
    },
    
    // Register new user
    register: async (userData) => {
        return apiRequest('/auth/register', 'POST', userData);
    },
    
    // Logout current user
    logout: async () => {
        const token = localStorage.getItem('token');
        return apiRequest('/auth/logout', 'POST', null, token);
    },
    
    // Get current user profile
    getProfile: async () => {
        const token = localStorage.getItem('token');
        return apiRequest('/users/me', 'GET', null, token);
    }
};

// User management functions
const users = {
    // Get user by ID
    getUser: async (userId) => {
        const token = localStorage.getItem('token');
        return apiRequest(`/users/${userId}`, 'GET', null, token);
    },
    
    // Update user profile
    updateProfile: async (userData) => {
        const token = localStorage.getItem('token');
        return apiRequest('/users/me', 'PUT', userData, token);
    }
};

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            try {
                const response = await auth.login(email, password);
                localStorage.setItem('token', response.access_token);
                
                // Redirect to dashboard or reload page
                window.location.href = '/dashboard.html';
            } catch (error) {
                alert('Login failed: ' + error.message);
            }
        });
    }
});

// Export API modules
window.api = {
    auth,
    users
};