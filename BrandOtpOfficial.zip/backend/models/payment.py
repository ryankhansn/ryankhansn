from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Literal

class PaymentOrderBase(BaseModel):
    """Base model for payment orders"""
    amount: float = Field(..., gt=0, description="Payment amount (must be greater than 0)")
    status: Literal["PENDING", "COMPLETED", "FAILED", "CANCELLED"] = "PENDING"

class PaymentOrderCreate(BaseModel):
    """Model for creating a payment order"""
    amount: float = Field(..., gt=0, description="Payment amount (must be greater than 0)")

class PaymentOrderInDB(PaymentOrderBase):
    """Model for payment order stored in database"""
    id: str
    user_id: str
    order_id: str
    payment_url: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class PaymentOrderResponse(PaymentOrderBase):
    """Model for payment order response"""
    order_id: str
    payment_url: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None