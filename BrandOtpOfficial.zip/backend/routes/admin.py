from fastapi import APIRouter, Depends, HTTPException, status, Query, Path
from datetime import datetime
from bson import ObjectId
from typing import List, Optional, Dict
import pymongo

# Changed from relative to absolute imports
from db import db, users_collection, services_collection, orders_collection, otp_requests_collection, get_db
from models import ServiceUpdate, ServiceResponse
from routes.auth import get_current_user
from routes.wallet import get_or_create_wallet

# Create router
router = APIRouter()

# Admin-only middleware
async def verify_admin(current_user = Depends(get_current_user)):
    """Verify that the current user has admin privileges"""
    # In a real application, you would check if the user has admin role
    # For now, we'll use a simple check based on email domain or specific emails
    if not current_user.email.endswith("@admin.com"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required"
        )
    return current_user

@router.get("/users")
async def get_all_users(admin = Depends(verify_admin)):
    """Return list of all users with their wallet balances"""
    users = list(users_collection.find({}, {"hashed_password": 0}))
    
    # Add wallet balance to each user
    for user in users:
        user["id"] = str(user["_id"])
        del user["_id"]
        
        # Get wallet balance
        wallet = await get_or_create_wallet(user["email"])
        user["wallet_balance"] = wallet["balance"]
    
    return users

@router.get("/services")
async def get_all_services(admin = Depends(verify_admin)):
    """Return list of all services (including inactive)"""
    services = list(services_collection.find({}))
    
    # Convert ObjectId to string for JSON serialization
    for service in services:
        service["id"] = str(service["_id"])
        del service["_id"]
    
    return services

@router.put("/service/{service_id}", response_model=ServiceResponse)
async def update_service(
    service_id: str = Path(..., title="The ID of the service to update"),
    service_update: ServiceUpdate = None,
    admin = Depends(verify_admin)
):
    """Update a service's my_price, base_price, or status"""
    # Check if service exists
    try:
        object_id = ObjectId(service_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid service ID format")
    
    existing_service = services_collection.find_one({"_id": object_id})
    if not existing_service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    # Update only provided fields
    update_data = {k: v for k, v in service_update.dict().items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No valid update data provided")
    
    # Update service
    services_collection.update_one({"_id": object_id}, {"$set": update_data})
    
    # Return updated service
    updated_service = services_collection.find_one({"_id": object_id})
    updated_service["id"] = str(updated_service["_id"])
    del updated_service["_id"]
    
    return updated_service

@router.get("/transactions")
async def get_all_transactions(
    user_id: Optional[str] = Query(None, description="Filter transactions by user ID"),
    start_date: Optional[str] = Query(None, description="Filter transactions by start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Filter transactions by end date (YYYY-MM-DD)"),
    admin = Depends(verify_admin)
):
    """Return all wallet transactions with optional filters"""
    from db import db
    
    # Build query filter
    query = {}
    
    # Add user_id filter if provided
    if user_id:
        query["user_id"] = user_id
    
    # Add date range filter if provided
    date_filter = {}
    if start_date:
        try:
            start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
            date_filter["$gte"] = start_datetime
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD")
    
    if end_date:
        try:
            # Set end_date to the end of the day
            end_datetime = datetime.strptime(end_date, "%Y-%m-%d")
            end_datetime = end_datetime.replace(hour=23, minute=59, second=59)
            date_filter["$lte"] = end_datetime
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD")
    
    if date_filter:
        query["transactions.timestamp"] = date_filter
    
    # Get all wallets matching the query
    wallets = list(db.wallets.find(query))
    
    # Extract all transactions
    all_transactions = []
    for wallet in wallets:
        user_id = wallet["user_id"]
        for transaction in wallet.get("transactions", []):
            # Add user_id to each transaction
            transaction_with_user = transaction.copy()
            transaction_with_user["user_id"] = user_id
            
            # Apply date filter directly to transactions if needed
            if date_filter:
                transaction_date = transaction["timestamp"]
                if ("$gte" in date_filter and transaction_date < date_filter["$gte"]) or \
                   ("$lte" in date_filter and transaction_date > date_filter["$lte"]):
                    continue
            
            all_transactions.append(transaction_with_user)
    
    # Sort transactions by timestamp (newest first)
    all_transactions.sort(key=lambda x: x["timestamp"], reverse=True)
    
    return all_transactions

@router.get("/search/users")
async def search_users(
    email: Optional[str] = Query(None, description="Search users by email"),
    username: Optional[str] = Query(None, description="Search users by username"),
    admin = Depends(verify_admin)
):
    """Search users by email or username"""
    # Build query filter
    query = {}
    
    if email:
        query["email"] = {"$regex": email, "$options": "i"}  # Case-insensitive search
    
    if username:
        query["username"] = {"$regex": username, "$options": "i"}  # Case-insensitive search
    
    if not query:
        raise HTTPException(status_code=400, detail="At least one search parameter (email or username) is required")
    
    # Find matching users
    users = list(users_collection.find(query, {"hashed_password": 0}))
    
    # Add wallet balance and format user data
    result = []
    for user in users:
        user_id = str(user["_id"])
        user_email = user["email"]
        
        # Get wallet balance
        wallet = await get_or_create_wallet(user_email)
        
        # Format user data
        user_data = {
            "id": user_id,
            "email": user_email,
            "username": user["username"],
            "wallet_balance": wallet["balance"],
            "created_at": user.get("created_at", datetime.utcnow()).isoformat()
        }
        
        result.append(user_data)
    
    return result

@router.get("/reports/summary")
async def get_summary_report(admin = Depends(verify_admin)):
    """Get summary report with key metrics"""
    # Count total users
    total_users = users_collection.count_documents({})
    
    # Count total transactions
    pipeline = [
        {"$project": {"transaction_count": {"$size": {"$ifNull": ["$transactions", []]}}}},
        {"$group": {"_id": None, "total": {"$sum": "$transaction_count"}}}
    ]
    transactions_result = list(db.wallets.aggregate(pipeline))
    total_transactions = transactions_result[0]["total"] if transactions_result else 0
    
    # Calculate total revenue (sum of successful payments)
    pipeline = [
        {"$match": {"status": "COMPLETED"}},
        {"$group": {"_id": None, "total_revenue": {"$sum": "$amount"}}}
    ]
    revenue_result = list(orders_collection.aggregate(pipeline))
    total_revenue = revenue_result[0]["total_revenue"] if revenue_result else 0
    
    # Count active services
    total_services_active = services_collection.count_documents({"status": "active"})
    
    return {
        "total_users": total_users,
        "total_transactions": total_transactions,
        "total_revenue": total_revenue,
        "total_services_active": total_services_active
    }

@router.get("/search/otp")
async def search_otp_requests(
    status: Optional[str] = Query(None, description="Filter by OTP status (pending, active, completed, cancelled)"),
    service_id: Optional[str] = Query(None, description="Filter by service ID"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    admin = Depends(verify_admin)
):
    """Search OTP requests by status, service_id, and user_id"""
    # Build query filter
    query = {}
    
    if status:
        valid_statuses = ["pending", "active", "completed", "cancelled"]
        if status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}")
        query["status"] = status
    
    if service_id:
        query["service_id"] = service_id
    
    if user_id:
        query["user_id"] = user_id
    
    # Find matching OTP requests
    otp_requests = list(otp_requests_collection.find(query).sort("created_at", pymongo.DESCENDING))
    
    # Format OTP request data
    result = []
    for request in otp_requests:
        request_data = {
            "id": str(request["_id"]),
            "service_id": request["service_id"],
            "number": request.get("number"),
            "status": request["status"],
            "created_at": request["created_at"].isoformat()
        }
        result.append(request_data)
    
    return result

@router.get("/search/orders")
async def search_orders(
    status: Optional[str] = Query(None, description="Filter by order status (PENDING, COMPLETED, FAILED, CANCELLED)"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    start_date: Optional[str] = Query(None, description="Start date for filtering (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date for filtering (YYYY-MM-DD)"),
    admin = Depends(verify_admin)
):
    """Search orders by status, user_id, and date range"""
    # Build query filter
    query = {}
    
    if status:
        valid_statuses = ["PENDING", "COMPLETED", "FAILED", "CANCELLED"]
        if status not in valid_statuses:
            raise HTTPException(status_code=400, detail=f"Invalid status. Must be one of: {', '.join(valid_statuses)}")
        query["status"] = status
    
    if user_id:
        query["user_id"] = user_id
    
    # Add date range filter if provided
    if start_date:
        try:
            start_datetime = datetime.strptime(start_date, "%Y-%m-%d")
            query["created_at"] = query.get("created_at", {})
            query["created_at"]["$gte"] = start_datetime
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid start_date format. Use YYYY-MM-DD")
    
    if end_date:
        try:
            # Set end_date to the end of the day
            end_datetime = datetime.strptime(end_date, "%Y-%m-%d")
            end_datetime = end_datetime.replace(hour=23, minute=59, second=59)
            query["created_at"] = query.get("created_at", {})
            query["created_at"]["$lte"] = end_datetime
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid end_date format. Use YYYY-MM-DD")
    
    # Find matching orders
    orders = list(orders_collection.find(query).sort("created_at", pymongo.DESCENDING))
    
    # Format order data
    result = []
    for order in orders:
        order_data = {
            "order_id": order["order_id"],
            "amount": order["amount"],
            "status": order["status"],
            "user_id": order["user_id"],
            "created_at": order["created_at"].isoformat()
        }
        result.append(order_data)
    
    return result