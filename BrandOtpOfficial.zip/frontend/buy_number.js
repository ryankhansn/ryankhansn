/**
 * BrandOtp - Buy Number Module
 * Handles OTP service integration for purchasing virtual numbers
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const buyNumberForm = document.getElementById('buy-number-form');
    const serviceSelect = document.getElementById('service-select');
    const activeNumberContainer = document.getElementById('active-number-container');
    const requestIdElement = document.getElementById('request-id');
    const phoneNumberElement = document.getElementById('phone-number');
    const numberStatusElement = document.getElementById('number-status');
    const otpCodeElement = document.getElementById('otp-code');
    const serviceNameElement = document.getElementById('service-name');
    const timeRemainingElement = document.getElementById('time-remaining');
    const cancelNumberBtn = document.getElementById('cancel-number-btn');
    const copyNumberBtn = document.getElementById('copy-number-btn');
    const copyOtpBtn = document.getElementById('copy-otp-btn');
    const recentNumbersTable = document.getElementById('recent-numbers');
    const noNumbersMessage = document.getElementById('no-numbers');
    const buyNumberError = document.getElementById('buy-number-error');

    // State variables
    let services = [];
    let currentOrderId = null;
    let pollingInterval = null;
    let timeoutTimer = null;

    // Initialize page
    initPage();

    /**
     * Initialize the page
     */
    async function initPage() {
        try {
            // Load available services
            await loadServices();
            
            // Set up event listeners
            setupEventListeners();
        } catch (error) {
            console.error('Error initializing page:', error);
            toast.error('Failed to initialize page. Please refresh and try again.');
        }
    }

    /**
     * Load available OTP services from the API
     */
    async function loadServices() {
        try {
            // Get JWT token from localStorage
            const token = localStorage.getItem('token');
            if (!token) {
                window.location.href = 'login.html';
                return;
            }

            // Show loading state
            serviceSelect.innerHTML = '<option value="" disabled selected>Loading services...</option>';
            
            // Fetch services from API
            const response = await fetch('http://127.0.0.1:8000/otp/services', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error('Failed to load services');
            }

            // Parse response
            services = await response.json();
            
            // Populate service select dropdown
            serviceSelect.innerHTML = '<option value="" disabled selected>Select a service</option>';
            
            services.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = `${service.name} - $${service.price.toFixed(2)}`;
                serviceSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Error loading services:', error);
            serviceSelect.innerHTML = '<option value="" disabled selected>Error loading services</option>';
            toast.error('Failed to load services. Please refresh and try again.');
        }
    }

    /**
     * Set up event listeners for the page
     */
    function setupEventListeners() {
        // Buy Number form submission
        if (buyNumberForm) {
            buyNumberForm.addEventListener('submit', handleBuyNumber);
        }

        // Cancel Number button
        if (cancelNumberBtn) {
            cancelNumberBtn.addEventListener('click', handleCancelNumber);
        }

        // Copy Number button
        if (copyNumberBtn) {
            copyNumberBtn.addEventListener('click', () => {
                copyToClipboard(phoneNumberElement.textContent);
            });
        }

        // Copy OTP button
        if (copyOtpBtn) {
            copyOtpBtn.addEventListener('click', () => {
                copyToClipboard(otpCodeElement.textContent);
            });
        }
    }

    /**
     * Handle Buy Number form submission
     * @param {Event} e - Form submit event
     */
    async function handleBuyNumber(e) {
        e.preventDefault();
        
        try {
            // Clear previous errors
            buyNumberError.textContent = '';
            
            // Get selected service
            const serviceId = serviceSelect.value;
            if (!serviceId) {
                buyNumberError.textContent = 'Please select a service';
                return;
            }
            
            // Get JWT token
            const token = localStorage.getItem('token');
            if (!token) {
                window.location.href = 'login.html';
                return;
            }
            
            // Disable form during submission
            const submitBtn = buyNumberForm.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            
            // Send request to buy number
            const response = await fetch('http://127.0.0.1:8000/otp/request', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    service_id: serviceId
                })
            });
            
            // Parse response
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.detail || 'Failed to purchase number');
            }
            
            // Display the virtual number and order details
            displayActiveNumber(data);
            
            // Start polling for OTP
            startPolling(data.request_id);
            
            // Reset form
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Buy Number';
            
        } catch (error) {
            console.error('Error buying number:', error);
            buyNumberError.textContent = error.message || 'Failed to purchase number';
            
            // Reset form
            const submitBtn = buyNumberForm.querySelector('button[type="submit"]');
            submitBtn.disabled = false;
            submitBtn.innerHTML = 'Buy Number';
            
            toast.error('Failed to purchase number. Please try again.');
        }
    }

    /**
     * Display active number details
     * @param {Object} data - Number purchase response data
     */
    function displayActiveNumber(data) {
        // Set current order ID
        currentOrderId = data.request_id;
        
        // Find service name
        const service = services.find(s => s.id === data.service_id);
        const serviceName = service ? service.name : 'Unknown Service';
        
        // Update UI elements
        requestIdElement.textContent = data.request_id;
        phoneNumberElement.textContent = data.number;
        numberStatusElement.textContent = data.status;
        numberStatusElement.className = `status-badge status-${data.status.toLowerCase()}`;
        otpCodeElement.textContent = 'Waiting for code...';
        serviceNameElement.textContent = serviceName;
        timeRemainingElement.textContent = '10:00';
        
        // Show active number container
        activeNumberContainer.style.display = 'block';
        
        // Disable OTP copy button until code is received
        copyOtpBtn.disabled = true;
        
        // Start countdown timer (10 minutes)
        startCountdownTimer(10 * 60);
        
        // Show success message
        toast.success('Number purchased successfully!');
    }

    /**
     * Start polling for OTP status
     * @param {string} orderId - Order ID to poll for
     */
    function startPolling(orderId) {
        // Clear any existing polling
        if (pollingInterval) {
            clearInterval(pollingInterval);
        }
        
        // Set polling interval (every 5 seconds)
        pollingInterval = setInterval(async () => {
            try {
                await checkOtpStatus(orderId);
            } catch (error) {
                console.error('Error checking OTP status:', error);
            }
        }, 5000);
    }

    /**
     * Check OTP status from the API
     * @param {string} orderId - Order ID to check
     */
    async function checkOtpStatus(orderId) {
        try {
            // Get JWT token
            const token = localStorage.getItem('token');
            if (!token) {
                stopPolling();
                return;
            }
            
            // Send request to check status
            const response = await fetch(`http://127.0.0.1:8000/otp/status/${orderId}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            // Parse response
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.detail || 'Failed to check OTP status');
            }
            
            // Update UI based on status
            updateOtpStatus(data);
            
        } catch (error) {
            console.error('Error checking OTP status:', error);
        }
    }

    /**
     * Update OTP status in the UI
     * @param {Object} data - OTP status data
     */
    function updateOtpStatus(data) {
        // Update status badge
        numberStatusElement.textContent = data.status;
        numberStatusElement.className = `status-badge status-${data.status.toLowerCase()}`;
        
        // If OTP received
        if (data.otp_code) {
            otpCodeElement.textContent = data.otp_code;
            otpCodeElement.classList.add('otp-received');
            copyOtpBtn.disabled = false;
            stopPolling();
            toast.success('OTP code received!');
        }
        
        // If failed or cancelled
        if (data.status === 'failed' || data.status === 'cancelled') {
            otpCodeElement.textContent = 'Failed to receive OTP';
            otpCodeElement.classList.add('otp-failed');
            stopPolling();
            stopCountdownTimer();
            toast.error(`OTP request ${data.status.toLowerCase()}: ${data.message || 'No reason provided'}`);
        }
    }

    /**
     * Handle Cancel Number button click
     */
    async function handleCancelNumber() {
        if (!currentOrderId) return;
        
        try {
            // Confirm cancellation
            if (!confirm('Are you sure you want to cancel this number request?')) {
                return;
            }
            
            // Get JWT token
            const token = localStorage.getItem('token');
            if (!token) {
                window.location.href = 'login.html';
                return;
            }
            
            // Disable cancel button
            cancelNumberBtn.disabled = true;
            cancelNumberBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cancelling...';
            
            // Send request to cancel number
            const response = await fetch(`http://127.0.0.1:8000/otp/cancel/${currentOrderId}`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            // Parse response
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.detail || 'Failed to cancel number');
            }
            
            // Update UI
            numberStatusElement.textContent = 'Cancelled';
            numberStatusElement.className = 'status-badge status-cancelled';
            otpCodeElement.textContent = 'Request cancelled';
            otpCodeElement.classList.add('otp-failed');
            
            // Stop polling and timer
            stopPolling();
            stopCountdownTimer();
            
            // Reset cancel button
            cancelNumberBtn.disabled = false;
            cancelNumberBtn.innerHTML = 'Cancel Number';
            
            toast.success('Number request cancelled successfully');
            
        } catch (error) {
            console.error('Error cancelling number:', error);
            
            // Reset cancel button
            cancelNumberBtn.disabled = false;
            cancelNumberBtn.innerHTML = 'Cancel Number';
            
            toast.error('Failed to cancel number. Please try again.');
        }
    }

    /**
     * Start countdown timer
     * @param {number} seconds - Total seconds for countdown
     */
    function startCountdownTimer(seconds) {
        // Clear any existing timer
        stopCountdownTimer();
        
        let remainingSeconds = seconds;
        
        // Update timer immediately
        updateTimerDisplay(remainingSeconds);
        
        // Set interval to update every second
        timeoutTimer = setInterval(() => {
            remainingSeconds--;
            
            // Update display
            updateTimerDisplay(remainingSeconds);
            
            // Check if timer expired
            if (remainingSeconds <= 0) {
                stopCountdownTimer();
                stopPolling();
                
                // Update UI
                numberStatusElement.textContent = 'Expired';
                numberStatusElement.className = 'status-badge status-expired';
                otpCodeElement.textContent = 'Request expired';
                otpCodeElement.classList.add('otp-failed');
                
                toast.error('OTP request expired. Please try again.');
            }
        }, 1000);
    }

    /**
     * Update timer display
     * @param {number} totalSeconds - Remaining seconds
     */
    function updateTimerDisplay(totalSeconds) {
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        timeRemainingElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    /**
     * Stop countdown timer
     */
    function stopCountdownTimer() {
        if (timeoutTimer) {
            clearInterval(timeoutTimer);
            timeoutTimer = null;
        }
    }

    /**
     * Stop polling for OTP
     */
    function stopPolling() {
        if (pollingInterval) {
            clearInterval(pollingInterval);
            pollingInterval = null;
        }
    }

    /**
     * Copy text to clipboard
     * @param {string} text - Text to copy
     */
    function copyToClipboard(text) {
        // Create temporary input element
        const input = document.createElement('input');
        input.value = text;
        document.body.appendChild(input);
        
        // Select and copy text
        input.select();
        document.execCommand('copy');
        
        // Remove temporary element
        document.body.removeChild(input);
        
        // Show success message
        toast.success('Copied to clipboard!');
    }
});